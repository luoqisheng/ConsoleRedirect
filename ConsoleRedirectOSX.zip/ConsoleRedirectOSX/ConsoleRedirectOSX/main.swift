//
//  main.swift
//  ConsoleRedirectOSX
//
//  Created by Luo Qisheng on 2022/8/16.
//

import Foundation
import DarkLightning

let inputArgs = CommandLine.arguments.dropFirst()
let console_path = inputArgs.first ?? "./console.log"

extension String {
    func appendLineToURL(fileURL: URL) throws {
         try (self + "\n").appendToURL(fileURL: fileURL)
     }

     func appendToURL(fileURL: URL) throws {
         let data = self.data(using: String.Encoding.utf8)!
         try data.append(fileURL: fileURL)
     }
 }

 extension Data {
     func append(fileURL: URL) throws {
         if let fileHandle = FileHandle(forWritingAtPath: fileURL.path) {
             defer {
                 fileHandle.closeFile()
             }
             fileHandle.seekToEndOfFile()
             fileHandle.write(self)
         }
         else {
             try write(to: fileURL, options: .atomic)
         }
     }
}

class USBDaemonDelegate: DaemonDelegate, DeviceDelegate {
    private var device: Device?

    func daemon(_ daemon: Daemon, didAttach device: Device) {
        if self.device == nil {
            self.device = device
            try? "".write(toFile: console_path, atomically: true, encoding: .utf8)
            device.connect()
        }
    }
    
    func daemon(_ daemon: Daemon, didDetach device: Device) {
        if let aDevice = self.device, device.isEqual(obj: aDevice) {
            self.device = nil
        }
    }
    
    func device(didDisconnect device: Device) {
        
    }
    
    func device(didConnect device: Device) {
        
    }
    
    func device(didFailToConnect device: Device) {
        
    }
    
    func device(_ device: Device, didReceiveData data: OOData) {
        let message = String(data: data.rawValue, encoding: .utf8)!
        try? message.appendToURL(fileURL: URL(fileURLWithPath: console_path))
    }
    
    
}

let delegate = USBDaemonDelegate()
var daemon = USBDaemon(delegate: delegate, deviceDelegate: delegate)
daemon.start()

RunLoop.current.run()
